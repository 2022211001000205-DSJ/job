﻿namespace WinFormsAppweek2
{
    partial class JobDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtWorkId = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            textBox1 = new TextBox();
            txtWorkId1 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            textBox10 = new TextBox();
            textBox11 = new TextBox();
            textBox13 = new TextBox();
            textBox14 = new TextBox();
            textBox15 = new TextBox();
            textBox16 = new TextBox();
            textBox17 = new TextBox();
            textBox18 = new TextBox();
            textBox19 = new TextBox();
            textBox20 = new TextBox();
            textBox21 = new TextBox();
            textBox22 = new TextBox();
            textBox23 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            dateTimePicker1 = new DateTimePicker();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(58, 36);
            label1.Name = "label1";
            label1.Size = new Size(46, 17);
            label1.TabIndex = 0;
            label1.Text = "CarNo";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(58, 69);
            label2.Name = "label2";
            label2.Size = new Size(56, 17);
            label2.TabIndex = 1;
            label2.Text = "JobData";
            // 
            // txtWorkId
            // 
            txtWorkId.AutoSize = true;
            txtWorkId.Location = new Point(58, 101);
            txtWorkId.Name = "txtWorkId";
            txtWorkId.Size = new Size(64, 17);
            txtWorkId.TabIndex = 2;
            txtWorkId.Text = "WorkerId";
            txtWorkId.Click += txtWorkId_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(58, 134);
            label4.Name = "label4";
            label4.Size = new Size(34, 17);
            label4.TabIndex = 3;
            label4.Text = "KMs";
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(58, 167);
            label5.Name = "label5";
            label5.Size = new Size(54, 17);
            label5.TabIndex = 7;
            label5.Text = "Tunning";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(58, 199);
            label6.Name = "label6";
            label6.Size = new Size(66, 17);
            label6.TabIndex = 6;
            label6.Text = "Alignment";
            label6.Click += label6_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(58, 233);
            label7.Name = "label7";
            label7.Size = new Size(64, 17);
            label7.TabIndex = 5;
            label7.Text = "Balancing";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(58, 264);
            label8.Name = "label8";
            label8.Size = new Size(36, 17);
            label8.TabIndex = 4;
            label8.Text = "Tires";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(58, 293);
            label9.Name = "label9";
            label9.Size = new Size(55, 17);
            label9.TabIndex = 10;
            label9.Text = "Weights";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(58, 327);
            label10.Name = "label10";
            label10.Size = new Size(76, 17);
            label10.TabIndex = 9;
            label10.Text = "OilChanged";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(58, 358);
            label11.Name = "label11";
            label11.Size = new Size(44, 17);
            label11.TabIndex = 8;
            label11.Text = "OilQty";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(397, 293);
            label12.Name = "label12";
            label12.Size = new Size(52, 17);
            label12.TabIndex = 21;
            label12.Text = "AirFilter";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(397, 327);
            label13.Name = "label13";
            label13.Size = new Size(59, 17);
            label13.TabIndex = 20;
            label13.Text = "Remarks";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(397, 167);
            label15.Name = "label15";
            label15.Size = new Size(71, 17);
            label15.TabIndex = 18;
            label15.Text = "Condenser";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(397, 199);
            label16.Name = "label16";
            label16.Size = new Size(33, 17);
            label16.TabIndex = 17;
            label16.Text = "Plug";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(397, 233);
            label17.Name = "label17";
            label17.Size = new Size(53, 17);
            label17.TabIndex = 16;
            label17.Text = "PlugQty";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(397, 264);
            label18.Name = "label18";
            label18.Size = new Size(59, 17);
            label18.TabIndex = 15;
            label18.Text = "FuelFilter";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(397, 134);
            label19.Name = "label19";
            label19.Size = new Size(37, 17);
            label19.TabIndex = 14;
            label19.Text = "Point";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(397, 101);
            label20.Name = "label20";
            label20.Size = new Size(72, 17);
            label20.TabIndex = 13;
            label20.Text = "GearOilQty";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(397, 69);
            label21.Name = "label21";
            label21.Size = new Size(52, 17);
            label21.TabIndex = 12;
            label21.Text = "GearOil";
            label21.Click += label21_Click;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(397, 36);
            label22.Name = "label22";
            label22.Size = new Size(52, 17);
            label22.TabIndex = 11;
            label22.Text = "OilFilter";
            label22.Click += label22_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(107, 36);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(185, 23);
            textBox1.TabIndex = 22;
            textBox1.Leave += textBox1_Leave;
            // 
            // txtWorkId1
            // 
            txtWorkId1.Location = new Point(107, 101);
            txtWorkId1.Name = "txtWorkId1";
            txtWorkId1.Size = new Size(185, 23);
            txtWorkId1.TabIndex = 24;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(107, 199);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(185, 23);
            textBox4.TabIndex = 27;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(107, 167);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(185, 23);
            textBox5.TabIndex = 26;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(107, 134);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(185, 23);
            textBox6.TabIndex = 25;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(107, 296);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(185, 23);
            textBox7.TabIndex = 30;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(107, 264);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(185, 23);
            textBox8.TabIndex = 29;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(107, 231);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(185, 23);
            textBox9.TabIndex = 28;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(114, 358);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(185, 23);
            textBox10.TabIndex = 32;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(114, 326);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(185, 23);
            textBox11.TabIndex = 31;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(446, 327);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(185, 23);
            textBox13.TabIndex = 42;
            // 
            // textBox14
            // 
            textBox14.Location = new Point(446, 297);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(185, 23);
            textBox14.TabIndex = 41;
            // 
            // textBox15
            // 
            textBox15.Location = new Point(446, 265);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(185, 23);
            textBox15.TabIndex = 40;
            // 
            // textBox16
            // 
            textBox16.Location = new Point(446, 232);
            textBox16.Name = "textBox16";
            textBox16.Size = new Size(185, 23);
            textBox16.TabIndex = 39;
            // 
            // textBox17
            // 
            textBox17.Location = new Point(446, 200);
            textBox17.Name = "textBox17";
            textBox17.Size = new Size(185, 23);
            textBox17.TabIndex = 38;
            // 
            // textBox18
            // 
            textBox18.Location = new Point(446, 168);
            textBox18.Name = "textBox18";
            textBox18.Size = new Size(185, 23);
            textBox18.TabIndex = 37;
            // 
            // textBox19
            // 
            textBox19.Location = new Point(446, 135);
            textBox19.Name = "textBox19";
            textBox19.Size = new Size(185, 23);
            textBox19.TabIndex = 36;
            // 
            // textBox20
            // 
            textBox20.Location = new Point(446, 102);
            textBox20.Name = "textBox20";
            textBox20.Size = new Size(185, 23);
            textBox20.TabIndex = 35;
            // 
            // textBox21
            // 
            textBox21.Location = new Point(446, 70);
            textBox21.Name = "textBox21";
            textBox21.Size = new Size(185, 23);
            textBox21.TabIndex = 34;
            // 
            // textBox22
            // 
            textBox22.Location = new Point(446, 37);
            textBox22.Name = "textBox22";
            textBox22.Size = new Size(185, 23);
            textBox22.TabIndex = 33;
            // 
            // textBox23
            // 
            textBox23.Location = new Point(300, 439);
            textBox23.Name = "textBox23";
            textBox23.Size = new Size(147, 23);
            textBox23.TabIndex = 44;
            // 
            // button1
            // 
            button1.Location = new Point(217, 439);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 45;
            button1.Text = "<";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(453, 439);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 46;
            button2.Text = ">";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(136, 439);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 47;
            button3.Text = "<<";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(534, 439);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 48;
            button4.Text = ">>";
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Location = new Point(90, 484);
            button5.Name = "button5";
            button5.Size = new Size(75, 23);
            button5.TabIndex = 49;
            button5.Text = "Load";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(180, 484);
            button6.Name = "button6";
            button6.Size = new Size(75, 23);
            button6.TabIndex = 50;
            button6.Text = "Add";
            button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Location = new Point(281, 484);
            button7.Name = "button7";
            button7.Size = new Size(75, 23);
            button7.TabIndex = 51;
            button7.Text = "Delete";
            button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.Location = new Point(372, 484);
            button8.Name = "button8";
            button8.Size = new Size(75, 23);
            button8.TabIndex = 52;
            button8.Text = "Cancel";
            button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Location = new Point(468, 484);
            button9.Name = "button9";
            button9.Size = new Size(75, 23);
            button9.TabIndex = 53;
            button9.Text = "Cancel All";
            button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Location = new Point(556, 484);
            button10.Name = "button10";
            button10.Size = new Size(75, 23);
            button10.TabIndex = 54;
            button10.Text = "Update";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // button11
            // 
            button11.Location = new Point(646, 484);
            button11.Name = "button11";
            button11.Size = new Size(75, 23);
            button11.TabIndex = 55;
            button11.Text = "Exit";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(107, 68);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(200, 23);
            dateTimePicker1.TabIndex = 56;
            // 
            // JobDetailsForm
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(870, 558);
            Controls.Add(dateTimePicker1);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox23);
            Controls.Add(textBox13);
            Controls.Add(textBox14);
            Controls.Add(textBox15);
            Controls.Add(textBox16);
            Controls.Add(textBox17);
            Controls.Add(textBox18);
            Controls.Add(textBox19);
            Controls.Add(textBox20);
            Controls.Add(textBox21);
            Controls.Add(textBox22);
            Controls.Add(textBox10);
            Controls.Add(textBox11);
            Controls.Add(textBox7);
            Controls.Add(textBox8);
            Controls.Add(textBox9);
            Controls.Add(textBox4);
            Controls.Add(textBox5);
            Controls.Add(textBox6);
            Controls.Add(txtWorkId1);
            Controls.Add(textBox1);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(label15);
            Controls.Add(label16);
            Controls.Add(label17);
            Controls.Add(label18);
            Controls.Add(label19);
            Controls.Add(label20);
            Controls.Add(label21);
            Controls.Add(label22);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(label7);
            Controls.Add(label8);
            Controls.Add(label4);
            Controls.Add(txtWorkId);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "JobDetailsForm";
            Text = "JobDetailsForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label txtWorkId;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private TextBox textBox1;
        private TextBox txtWorkId1;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox9;
        private TextBox textBox10;
        private TextBox textBox11;
        private TextBox textBox13;
        private TextBox textBox14;
        private TextBox textBox15;
        private TextBox textBox16;
        private TextBox textBox17;
        private TextBox textBox18;
        private TextBox textBox19;
        private TextBox textBox20;
        private TextBox textBox21;
        private TextBox textBox22;
        private TextBox textBox23;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private DateTimePicker dateTimePicker1;
    }
}