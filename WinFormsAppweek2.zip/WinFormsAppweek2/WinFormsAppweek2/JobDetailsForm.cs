﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsAppweek2
{
    public partial class JobDetailsForm : Form
    {
        public JobDetailsForm()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if ((textBox1.Text == "") || (textBox1.Text == null))
            {
                MessageBox.Show("wrong");
                textBox1.Focus();
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text.Length < 6)
                {
                    MessageBox.Show("Please Specify a vaild car number");
                    textBox1.Focus();
                    return;
                }
                if (Convert.ToInt16(txtWorkId1.Text) < 1)
                {
                    MessageBox.Show("please enter a vaild worker id");
                    txtWorkId1.Focus();
                    return;
                }
                if (Convert.ToDateTime(dateTimePicker1.Text) > DateTime.Today)
                {
                    MessageBox.Show("Time error");
                    dateTimePicker1.Focus();
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtWorkId_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
