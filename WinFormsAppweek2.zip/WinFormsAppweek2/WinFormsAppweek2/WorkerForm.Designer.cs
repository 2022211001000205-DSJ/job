﻿namespace WinFormsAppweek2
{
    partial class WorkerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            btnSave = new Button();
            btnEdit = new Button();
            btnCancel = new Button();
            btnExit = new Button();
            dataGridView1 = new DataGridView();
            projectDataBindingSource1 = new BindingSource(components);
            projectDataBindingSource = new BindingSource(components);
            form1BindingSource = new BindingSource(components);
            form1BindingSource1 = new BindingSource(components);
            form1BindingSource2 = new BindingSource(components);
            dataGridViewComboBoxEditingControlBindingSource = new BindingSource(components);
            autoCompleteCustomSourceBindingSource = new BindingSource(components);
            lengthDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)projectDataBindingSource1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)projectDataBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)form1BindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)form1BindingSource1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)form1BindingSource2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewComboBoxEditingControlBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)autoCompleteCustomSourceBindingSource).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(222, 26);
            label1.Name = "label1";
            label1.Size = new Size(282, 16);
            label1.TabIndex = 0;
            label1.Text = "Click on The Edit Button to load the records";
            // 
            // btnSave
            // 
            btnSave.Location = new Point(76, 297);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 1;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += button1_Click;
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(222, 297);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(75, 23);
            btnEdit.TabIndex = 2;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(384, 297);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 3;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(548, 297);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(75, 23);
            btnExit.TabIndex = 4;
            btnExit.Text = "Exit";
            btnExit.TextAlign = ContentAlignment.TopCenter;
            btnExit.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { lengthDataGridViewTextBoxColumn });
            dataGridView1.DataSource = autoCompleteCustomSourceBindingSource;
            dataGridView1.Location = new Point(54, 88);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(628, 150);
            dataGridView1.StandardTab = true;
            dataGridView1.TabIndex = 5;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // projectDataBindingSource1
            // 
            projectDataBindingSource1.DataSource = typeof(Microsoft.VisualBasic.CompilerServices.ProjectData);
            // 
            // projectDataBindingSource
            // 
            projectDataBindingSource.DataSource = typeof(Microsoft.VisualBasic.CompilerServices.ProjectData);
            // 
            // form1BindingSource
            // 
            form1BindingSource.DataSource = typeof(Form1);
            // 
            // form1BindingSource1
            // 
            form1BindingSource1.DataSource = typeof(Form1);
            // 
            // form1BindingSource2
            // 
            form1BindingSource2.DataSource = typeof(Form1);
            // 
            // dataGridViewComboBoxEditingControlBindingSource
            // 
            dataGridViewComboBoxEditingControlBindingSource.DataSource = typeof(DataGridViewComboBoxEditingControl);
            // 
            // autoCompleteCustomSourceBindingSource
            // 
            autoCompleteCustomSourceBindingSource.DataMember = "AutoCompleteCustomSource";
            autoCompleteCustomSourceBindingSource.DataSource = dataGridViewComboBoxEditingControlBindingSource;
            // 
            // lengthDataGridViewTextBoxColumn
            // 
            lengthDataGridViewTextBoxColumn.DataPropertyName = "Length";
            lengthDataGridViewTextBoxColumn.HeaderText = "Length";
            lengthDataGridViewTextBoxColumn.Name = "lengthDataGridViewTextBoxColumn";
            lengthDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // WorkerForm
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dataGridView1);
            Controls.Add(btnExit);
            Controls.Add(btnCancel);
            Controls.Add(btnEdit);
            Controls.Add(btnSave);
            Controls.Add(label1);
            Name = "WorkerForm";
            Text = "WorkerForm";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)projectDataBindingSource1).EndInit();
            ((System.ComponentModel.ISupportInitialize)projectDataBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)form1BindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)form1BindingSource1).EndInit();
            ((System.ComponentModel.ISupportInitialize)form1BindingSource2).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewComboBoxEditingControlBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)autoCompleteCustomSourceBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnSave;
        private Button btnEdit;
        private Button btnCancel;
        private Button btnExit;
        private BindingSource form1BindingSource1;
        private BindingSource form1BindingSource;
        private BindingSource form1BindingSource2;
        private BindingSource projectDataBindingSource;
        private BindingSource dataGridViewComboBoxEditingControlBindingSource;
        private BindingSource projectDataBindingSource1;
        public DataGridView dataGridView1;
        private DataGridViewTextBoxColumn lengthDataGridViewTextBoxColumn;
        private BindingSource autoCompleteCustomSourceBindingSource;
    }
}